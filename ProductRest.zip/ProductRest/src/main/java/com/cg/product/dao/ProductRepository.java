package com.cg.product.dao;

import java.util.ArrayList;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cg.product.dto.Product;

@Repository
@Transactional
public interface ProductRepository extends JpaRepository<Product, Integer>
{
	@Query("SELECT productList FROM Product productList")
	public ArrayList<Product> getAllProducts();
	
	@Query("SELECT product FROM Product product WHERE product.productId=:id")
	public Product getProductById(@Param("id") int id);
	
	@Modifying
	@Query("DELETE FROM Product product WHERE product.productId=:id")
	public void deleteProductById(@Param("id") int id);

	@Modifying
	@Query("UPDATE Product product SET product.productName=:name, product.productPrice=:price WHERE product.productId=:id")
	public void updateProductById(@Param("id") int id,@Param("name") String name,@Param("price") double price);
}
