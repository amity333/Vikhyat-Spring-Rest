package com.cg.product.service;

import java.util.ArrayList;

import com.cg.product.dto.Product;


public interface ProductService
{
	public Product addProduct(Product product);
	public ArrayList<Product> getAllProducts();
	public Product getProductById(int id);
	public void deleteProductById(int id);
	public void updateProductById(int id,String name,double price);
}
