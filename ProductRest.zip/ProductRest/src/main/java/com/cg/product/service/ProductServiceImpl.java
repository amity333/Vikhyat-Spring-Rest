package com.cg.product.service;

import java.util.ArrayList;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.product.dao.ProductRepository;
import com.cg.product.dto.Product;

@Service
@Transactional
public class ProductServiceImpl implements ProductService
{
	@Autowired
	ProductRepository productDao;

	@Override
	public ArrayList<Product> getAllProducts() {
		// TODO Auto-generated method stub
		return productDao.getAllProducts();
	}

	@Override
	public Product getProductById(int id) {
		// TODO Auto-generated method stub
		return productDao.getProductById(id);
	}

	@Override
	public void deleteProductById(int id) {
		// TODO Auto-generated method stub
		productDao.deleteProductById(id);
	}

	@Override
	public void updateProductById(int id, String name, double price) {
		// TODO Auto-generated method stub
		productDao.updateProductById(id, name, price);
	}

	@Override
	public Product addProduct(Product product) {
		// TODO Auto-generated method stub
		return productDao.save(product);
	}
}
