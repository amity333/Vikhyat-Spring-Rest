package com.cg.product.ctrl;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.product.dto.Product;
import com.cg.product.exceptions.ProductNotFoundException;
import com.cg.product.service.ProductService;

@RestController
public class ProductController
{
	@Autowired
	ProductService prodSer;
	
	@RequestMapping(value="/showAllProducts",method=RequestMethod.GET,headers="Accept=application/json")
	public ArrayList<Product> showAllProducts()
	{
		return prodSer.getAllProducts();
	}
	
	@PostMapping(value="/addUser",consumes=MediaType.APPLICATION_JSON_VALUE , headers="Accept=application/json",produces=MediaType.APPLICATION_JSON_VALUE)
	public Product newProduct(@RequestBody Product prod)
	{
		prodSer.addProduct(prod);
		Product product=prodSer.getProductById(prod.getProductId());
		return product;
	}
	
	@DeleteMapping(value="/deleteUser/{id}", headers="Accept=application/json")
	public void deleteProduct(@PathVariable("id") int id)
	{
		prodSer.deleteProductById(id);
		System.out.println("Deleted data");
	}
	
	@PutMapping(value="/user/update/",consumes=MediaType.APPLICATION_JSON_VALUE, headers="Accept=application/json")
	public void updateProduct(@RequestBody Product product)
	{
		prodSer.updateProductById(product.getProductId(), product.getProductName(), product.getProductPrice());
		System.out.println("Updated data");
	}
	
	@GetMapping(value="searchUser/{id}")
	public Product showProduct(@PathVariable("id") int id) throws ProductNotFoundException
	{
		Product pro=prodSer.getProductById(id);
		if(pro==null) {
			throw new ProductNotFoundException("Wrong Product Id");
		}
		else
		{
		return pro;
		}
	}
}
